document.addEventListener('DOMContentLoaded', () => {
    console.log('JavaScript loaded!');

    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', () => {
            alert('Post added successfully!');
        });
    }
});
